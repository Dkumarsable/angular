import { Component, OnInit } from '@angular/core';
import {OwlCarousel} from 'ngx-owl-carousel';
import {ViewChild} from '@angular/core'
import { Taxi } from "../models/taxi";
import {ServicesService} from '../services.service';

@Component({
  selector: 'app-taxi',
  templateUrl: './taxi.component.html',
  styleUrls: ['./taxi.component.css']
  
})
export class TaxiComponent implements OnInit {
   
   
     model = new Taxi();

  constructor( private servicesService:ServicesService) { }
  Reserve = false;
	  onReserve(){ 
     this.Reserve = true,
 
   this.servicesService.createTaxi(this.model);
	   }
 
 
 
 onEdit(){
    window.scrollTo(0,0);
  }
 /*
 mySlideImages = [1,2,3,4,5,6,7,8,9].map((i)=> `https://picsum.photos/640/480?image=${i}`);
 mySlideOptions={items: 3, dots: true, nav: false};
*/

// model:any={};
 
 mySlideImages : String[] = [ 
  'http://maxitaxibooking.wavsydney.com.au/wp-content/uploads/2018/04/WAV1.jpg',
  'https://i.ebayimg.com/00/s/MTIwMFgxNjAw/z/zMYAAOSwStZbcrVb/$_20.JPG',
  'http://maxitaxibooking.wavsydney.com.au/wp-content/uploads/2018/04/WAV1.jpg',
  'http://maxitaxibooking.wavsydney.com.au/wp-content/uploads/2018/04/WAV1.jpg',
  'http://maxitaxibooking.wavsydney.com.au/wp-content/uploads/2018/04/WAV1.jpg',
  'https://i.ebayimg.com/00/s/MTIwMFgxNjAw/z/zMYAAOSwStZbcrVb/$_20.JPG',
  'https://i.ebayimg.com/00/s/MTIwMFgxNjAw/z/zMYAAOSwStZbcrVb/$_20.JPG',
  'http://maxitaxibooking.wavsydney.com.au/wp-content/uploads/2018/04/WAV1.jpg',
  'http://maxitaxibooking.wavsydney.com.au/wp-content/uploads/2018/04/WAV1.jpg',
  'http://maxitaxibooking.wavsydney.com.au/wp-content/uploads/2018/04/wav-customers2.jpeg',
  'http://maxitaxibooking.wavsydney.com.au/wp-content/uploads/2018/04/wav-customers2.jpeg',
  'http://maxitaxibooking.wavsydney.com.au/wp-content/uploads/2018/04/wav-customers2.jpeg',
  'http://maxitaxibooking.wavsydney.com.au/wp-content/uploads/2018/04/wav-customers2.jpeg'
  ];
 mySlideOptions={items: 3, dots: true, nav: false};

 
  
	  
 
  ngOnInit() {
  }

}
