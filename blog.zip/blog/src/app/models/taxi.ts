export class Taxi {
	number : number;
	pickup : string;
	dropoff: string;	
	datd   :  string;
	time   :  string;
	now    : string;
	later  : string;
}