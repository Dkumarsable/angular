import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {Routes, RouterModule} from '@angular/router';
import {PublicComponent} from './layouts/public/public.component';
import {HeroFormComponent} from './hero-form/hero-form.component';
import {LinkComponent} from './link/link.component';
import {ContactComponent} from './contact/contact.component';
import {TaxiComponent} from './taxi/taxi.component';

const PUBLIC_ROUTES : Routes = [

    {path : 'post', loadChildren : './post/post.module#PostModule' },
	{ path : 'hero', component : HeroFormComponent},
	{ path : 'link', component : LinkComponent},
	{ path : 'contact', component : ContactComponent},
	{ path : 'taxi', component : TaxiComponent}
]

const routes : Routes = [
{ path : '', component : PublicComponent, data : { title : 'public Views'}, children :PUBLIC_ROUTES }
]

@NgModule({
  imports: [
    RouterModule.forRoot(routes,{ useHash : true })
  ],
  exports:[RouterModule]
})
export class AppRoutingModule { }
