import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import {AppRoutingModule } from './app-routing.module';
import {FormsModule} from '@angular/forms';
import { PublicComponent } from './layouts/public/public.component';
import { HeroFormComponent } from './hero-form/hero-form.component';
import {HttpClientModule} from '@angular/common/http';
import {ServicesService} from './services.service';
import { HttpModule } from '@angular/http';
import { LinkComponent } from './link/link.component';
import { ContactComponent } from './contact/contact.component';
import { TaxiComponent } from './taxi/taxi.component';
import { ScrollToModule } from 'ng2-scroll-to-el';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { OwlModule } from 'ngx-owl-carousel';


@NgModule({
  declarations: [
    AppComponent,
    PublicComponent,
    HeroFormComponent,
    LinkComponent,
    ContactComponent,
    TaxiComponent,
   
    

   ],
  imports: [
    BrowserModule,AppRoutingModule,FormsModule,	HttpClientModule,HttpModule,AngularFontAwesomeModule,OwlModule,
	 
	ScrollToModule.forRoot()
  ],
  providers: [ServicesService],
  bootstrap: [AppComponent]
})
export class AppModule { }
